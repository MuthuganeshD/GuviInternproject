<?php
session_start();
include 'config.php';

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mail = $_POST['mail'];
    $pass = $_POST['pass'];

    // Validate inputs
    if (empty($mail) || empty($pass)) {
        $response['success'] = false;
        $response['message'] = "mail and pass are required.";
    } else {
        // Sanitize inputs
        $mail = mysqli_real_escape_string($conn, $mail);
        $pass = mysqli_real_escape_string($conn, $pass);

        // Check user credentials in the database
        $sql = "SELECT id, mail FROM login WHERE mail = ? AND pass = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $mail, $pass);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $mail);
            $stmt->fetch();

            // Set user session
            $_SESSION['id'] = $user_id;
            $_SESSION['mail'] = $mail;

            $response['success'] = true;
            $response['message'] = "Login successful.";
        } else {
            $response['success'] = false;
            $response['message'] = "Invalid mail or pass.";
        }

        $stmt->close();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

header('Content-Type: application/json');
echo json_encode($response);
