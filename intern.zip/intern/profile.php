<?php
session_start();
include 'config.php';
include 'auth.php';
$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Perform Read operation (GET request)
    $id = $_SESSION['id'];
    $sql = "SELECT * FROM login WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response['success'] = true;
        $response['data'] = $row;
    } else {
        $response['success'] = false;
        $response['message'] = "User not found.";
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Perform Update operation (PUT request)
    parse_str(file_get_contents("php://input"), $putData);
    $dob = $putData['dob'];
    $phone = $putData['phone'];
    $uname = $putData['uname'];
    $mail = $putData['mail'];
    $address = $putData['address'];

    // Validate and sanitize input
    if (empty($dob) || empty($phone) || empty($uname) || empty($mail)) {
        $response['success'] = false;
        $response['message'] = "Please provide all required fields.";
    } else {
        // Update user details in the database
        $id = $_SESSION['id'];
        $sql = "UPDATE login SET dob = ?, phone = ?, uname = ? , mail = ?, address=? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $dob, $phone, $uname, $mail,$address,$id);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Details updated successfully.";
        } else {
            $response['success'] = false;
            $response['message'] = "Failed to update details.";
        }

        $stmt->close();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

header('Content-Type: application/json');
echo json_encode($response);
?>
