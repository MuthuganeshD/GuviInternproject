<?php
session_start();
include 'config.php';
$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uname = $_POST['uname'];
    $mail = $_POST['mail'];
    $pass = $_POST['pass'];

    // Validate inputs
    if (empty($mail) || empty($pass)) {
        $response['success'] = false;
        $response['message'] = "mail and pass are required.";
    } else {
        // Sanitize inputs
        $uname = mysqli_real_escape_string($conn, $uname);
        $mail = mysqli_real_escape_string($conn, $mail);
        $pass = mysqli_real_escape_string($conn, $pass);

        // Insert user data into the database
        $sql = "INSERT INTO login (uname,mail, pass) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $uname, $mail, $pass);

        if ($stmt->execute()) {
            // Set user session
            $user_id = $stmt->insert_id;
            $_SESSION['id'] = $user_id;
            $_SESSION['mail'] = $mail;

            $response['success'] = true;
            $response['message'] = "Registration successful.";
        } else {
            $response['success'] = false;
            $response['message'] = "Registration failed.";
        }

        $stmt->close();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

header('Content-Type: application/json');
echo json_encode($response);